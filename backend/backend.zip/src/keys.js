module.exports = {
  database: {
    host: "localhost",
    user: "root",
    password: "",
    database: "bd_nutricion",
  },
  webPush: {
    publicKey:
      "BLR9q6Fg569A3GOQpzi4h7CHz5b4DIg7Pf6QuFvE4pkTgRuT4jnliaoW7khmFjHJk6xxPwPJllijA79yuQHyMRY",
    privateKey: "IngHjcAtXP4HSGj6HVeUzyj0vP88pIj36t_iO_kQb-E",
  },
};

/*
module.exports = {
  database: {
    host: "localhost",
    user: "test_nutricion",
    password: "fs6X!73j",
    database: "bd_nutricion",
  },
  webPush: {
    publicKey:
      "BLR9q6Fg569A3GOQpzi4h7CHz5b4DIg7Pf6QuFvE4pkTgRuT4jnliaoW7khmFjHJk6xxPwPJllijA79yuQHyMRY",
    privateKey: "IngHjcAtXP4HSGj6HVeUzyj0vP88pIj36t_iO_kQb-E",
  },
};


*/
